
# ZGZO.AI GC Config Creator

This app lets General Contractors create branded configuration profiles that plug into the ZGZO.AI AI bidding engine.

## How to Deploy on Streamlit Cloud

1. Go to https://streamlit.io/cloud and log in with your GitHub account
2. Create a new app and connect it to this repo
3. Deploy `app.py`

That’s it — your branded GC profile creator is live!
